/* ============================================================
   TechNova — Form Validation
   ============================================================ */

const TN_EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const TN_PHONE_RE = /^[0-9+\-\s()]+$/;

function tnSetError(inputEl, message) {
  const group = inputEl.closest(".tn-field") || inputEl.parentElement;
  const errorEl = group.querySelector(".tn-error");
  inputEl.classList.toggle("is-invalid", !!message);
  inputEl.classList.toggle("is-valid", !message && inputEl.value.trim() !== "");
  if (errorEl) {
    errorEl.textContent = message || "";
    errorEl.classList.toggle("tn-show-error", !!message);
  }
  return !message;
}

function tnValidateRequired(inputEl, label) {
  const val = inputEl.value.trim();
  if (val === "") return tnSetError(inputEl, `${label} is required.`);
  return tnSetError(inputEl, "");
}

function tnValidateName(inputEl) {
  const val = inputEl.value.trim();
  if (val === "") return tnSetError(inputEl, "Name is required.");
  if (val.length < 2) return tnSetError(inputEl, "Name must be at least 2 characters.");
  return tnSetError(inputEl, "");
}

function tnValidateEmail(inputEl) {
  const val = inputEl.value.trim();
  if (val === "") return tnSetError(inputEl, "Email is required.");
  if (!TN_EMAIL_RE.test(val)) return tnSetError(inputEl, "Enter a valid email address.");
  return tnSetError(inputEl, "");
}

function tnValidatePhone(inputEl) {
  const val = inputEl.value.trim();
  if (val === "") return tnSetError(inputEl, "Phone number is required.");
  if (!TN_PHONE_RE.test(val)) return tnSetError(inputEl, "Phone number can contain only digits, +, -, spaces and ().");
  const digits = val.replace(/\D/g, "");          // sirf numbers count karo
  if (digits.length < 10) return tnSetError(inputEl, "Phone number must have at least 10 digits.");
  if (digits.length > 15) return tnSetError(inputEl, "Phone number can have at most 15 digits.");
  return tnSetError(inputEl, "");
}

function tnValidatePassword(inputEl, minLen = 6) {
  const val = inputEl.value;
  if (val === "") return tnSetError(inputEl, "Password is required.");
  if (val.length < minLen) return tnSetError(inputEl, `Password must be at least ${minLen} characters.`);
  return tnSetError(inputEl, "");
}

/* Strong password: 8+ chars, uppercase, lowercase, number, special character, no spaces */
function tnValidateStrongPassword(inputEl, minLen = 8) {
  const val = inputEl.value;
  if (val === "") return tnSetError(inputEl, "Password is required.");
  if (val.length < minLen) return tnSetError(inputEl, `Password must be at least ${minLen} characters.`);
  if (/\s/.test(val)) return tnSetError(inputEl, "Password must not contain spaces.");
  if (!/[A-Z]/.test(val)) return tnSetError(inputEl, "Password must contain at least one uppercase letter (A-Z).");
  if (!/[a-z]/.test(val)) return tnSetError(inputEl, "Password must contain at least one lowercase letter (a-z).");
  if (!/[0-9]/.test(val)) return tnSetError(inputEl, "Password must contain at least one number (0-9).");
  if (!/[^A-Za-z0-9\s]/.test(val)) return tnSetError(inputEl, "Password must contain at least one special character (e.g. @ # $ % ! &).");
  return tnSetError(inputEl, "");
}

/* Confirm password must match */
function tnValidateConfirmPassword(confirmEl, passwordEl) {
  if (confirmEl.value === "") return tnSetError(confirmEl, "Please confirm your password.");
  if (confirmEl.value !== passwordEl.value) return tnSetError(confirmEl, "Passwords do not match.");
  return tnSetError(confirmEl, "");
}

function tnValidateMessage(inputEl) {
  const val = inputEl.value.trim();
  if (val === "") return tnSetError(inputEl, "Message is required.");
  if (val.length < 10) return tnSetError(inputEl, "Message must be at least 10 characters.");
  return tnSetError(inputEl, "");
}

function tnValidateNumber(inputEl, label) {
  const val = inputEl.value.trim();
  if (val === "") return tnSetError(inputEl, `${label} is required.`);
  if (isNaN(val) || Number(val) < 0) return tnSetError(inputEl, `${label} must be a valid number.`);
  return tnSetError(inputEl, "");
}

/* ---------- Password show/hide ---------- */
document.addEventListener("click", (e) => {
  const toggle = e.target.closest("[data-tn-toggle-password]");
  if (!toggle) return;
  const targetId = toggle.getAttribute("data-tn-toggle-password");
  const input = document.getElementById(targetId);
  if (!input) return;
  const icon = toggle.querySelector("i");
  if (input.type === "password") {
    input.type = "text";
    if (icon) { icon.classList.remove("bi-eye"); icon.classList.add("bi-eye-slash"); }
  } else {
    input.type = "password";
    if (icon) { icon.classList.remove("bi-eye-slash"); icon.classList.add("bi-eye"); }
  }
});

/* ---------- Contact Form ---------- */
document.addEventListener("DOMContentLoaded", () => {
  const contactForm = document.getElementById("tnContactForm");
  if (contactForm) {
    contactForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const name = document.getElementById("tnName");
      const email = document.getElementById("tnEmail");
      const phone = document.getElementById("tnPhone");
      const subject = document.getElementById("tnSubject");
      const message = document.getElementById("tnMessage");

      const ok = [
        tnValidateName(name),
        tnValidateEmail(email),
        tnValidatePhone(phone),
        tnValidateRequired(subject, "Subject"),
        tnValidateMessage(message),
      ].every(Boolean);

      if (ok) {
        tnShowToast("Message sent! We'll get back to you soon.");
        contactForm.reset();
        contactForm.querySelectorAll(".is-valid").forEach((el) => el.classList.remove("is-valid"));
      }
    });
  }

  /* ---------- Customer Login Form ---------- */
  const loginForm = document.getElementById("tnLoginForm");
  if (loginForm) {
    loginForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const email = document.getElementById("tnLoginEmail");
      const password = document.getElementById("tnLoginPassword");
      const ok = [tnValidateEmail(email), tnValidatePassword(password)].every(Boolean);
      if (ok) {
        tnShowToast("Login successful! Redirecting…");
        setTimeout(() => (window.location.href = "index.html"), 900);
      }
    });
  }

  /* ---------- Customer Register Form ---------- */
  const registerForm = document.getElementById("tnRegisterForm");
  if (registerForm) {
    const name = document.getElementById("tnRegisterName");
    const email = document.getElementById("tnRegisterEmail");
    const password = document.getElementById("tnRegisterPassword");
    const confirmPassword = document.getElementById("tnRegisterConfirmPassword");
    const phone = document.getElementById("tnRegisterPhone");
    const terms = document.getElementById("tnRegisterTerms");

    function checkTerms() {
      const termsGroup = terms.closest(".tn-field");
      const termsError = termsGroup ? termsGroup.querySelector(".tn-error") : null;
      const termsOk = terms.checked;
      if (termsError) {
        termsError.textContent = termsOk ? "" : "Please accept the Terms of Service to continue.";
        termsError.classList.toggle("tn-show-error", !termsOk);
      }
      return termsOk;
    }

    /* Live validation: user type karte hi / field chhodte hi error dikhe */
    name.addEventListener("blur", () => tnValidateName(name));
    email.addEventListener("blur", () => tnValidateEmail(email));
    password.addEventListener("input", () => {
      tnValidateStrongPassword(password);
      if (confirmPassword.value !== "") tnValidateConfirmPassword(confirmPassword, password);
    });
    confirmPassword.addEventListener("input", () => tnValidateConfirmPassword(confirmPassword, password));
    phone.addEventListener("input", () => {
      phone.value = phone.value.replace(/[^0-9+\-\s()]/g, ""); // letters block
      tnValidatePhone(phone);
    });
    terms.addEventListener("change", checkTerms);

    registerForm.addEventListener("submit", (e) => {
      e.preventDefault();

      const ok = [
        tnValidateName(name),
        tnValidateEmail(email),
        tnValidateStrongPassword(password),
        tnValidateConfirmPassword(confirmPassword, password),
        tnValidatePhone(phone),
        checkTerms(),
      ].every(Boolean);

      if (ok) {
        tnShowToast("Account created! Redirecting to login…");
        setTimeout(() => (window.location.href = "login.html"), 900);
      }
    });
  }

  /* ---------- Admin Login Form ---------- */
  const adminLoginForm = document.getElementById("tnAdminLoginForm");
  if (adminLoginForm) {
    adminLoginForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const username = document.getElementById("tnAdminUsername");
      const password = document.getElementById("tnAdminPassword");
      const fieldsOk = [tnValidateRequired(username, "Username"), tnValidateRequired(password, "Password")].every(Boolean);
      if (!fieldsOk) return;

      const TN_ADMIN_USER = "admin";
      const TN_ADMIN_PASS = "admin123";
      const usernameOk = tnSetError(username, username.value.trim() === TN_ADMIN_USER ? "" : "Incorrect username.");
      const passwordOk = tnSetError(password, password.value === TN_ADMIN_PASS ? "" : "Incorrect password.");

      if (usernameOk && passwordOk) {
        tnShowToast("Welcome back, Admin!");
        setTimeout(() => (window.location.href = "dashboard.html"), 900);
      }
    });
  }

  /* ---------- Add Product Form ---------- */
  const addProductForm = document.getElementById("tnAddProductForm");
  if (addProductForm) {
    addProductForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const pname = document.getElementById("tnPName");
      const brand = document.getElementById("tnPBrand");
      const category = document.getElementById("tnPCategory");
      const price = document.getElementById("tnPPrice");
      const stock = document.getElementById("tnPStock");
      const description = document.getElementById("tnPDescription");

      const ok = [
        tnValidateRequired(pname, "Product name"),
        tnValidateRequired(brand, "Brand"),
        tnValidateRequired(category, "Category"),
        tnValidateNumber(price, "Price"),
        tnValidateNumber(stock, "Stock"),
        tnValidateRequired(description, "Description"),
      ].every(Boolean);

      if (ok) {
        tnShowToast("Product saved successfully!");
        addProductForm.reset();
        addProductForm.querySelectorAll(".is-valid").forEach((el) => el.classList.remove("is-valid"));
      }
    });
    const resetBtn = document.getElementById("tnResetBtn");
    if (resetBtn) {
      resetBtn.addEventListener("click", () => {
        addProductForm.querySelectorAll(".is-valid, .is-invalid").forEach((el) => {
          el.classList.remove("is-valid", "is-invalid");
        });
      });
    }
  }
});
