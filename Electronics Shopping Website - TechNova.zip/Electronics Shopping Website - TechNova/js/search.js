/* ============================================================
   TechNova — Products Listing: Search, Filter, Sort
   ============================================================ */

let tnActiveFilters = {
  query: "",
  categories: [],
  maxPrice: 200000,
  sort: "default",
  page: 1,
};
const TN_PAGE_SIZE = 8;
let tnFilteredItems = [];

function tnGetUrlParam(name) {
  return new URLSearchParams(window.location.search).get(name);
}

function tnRenderCategoryFilters() {
  const box = document.getElementById("tnCategoryFilters");
  if (!box) return;
  box.innerHTML = TN_CATEGORIES.map(
    (c) => `
    <div class="form-check">
      <input class="form-check-input tn-cat-check" type="checkbox" value="${c.id}" id="cat-${c.id}">
      <label class="form-check-label" for="cat-${c.id}">${c.name} <span class="text-muted">(${c.count})</span></label>
    </div>`
  ).join("");

  document.querySelectorAll(".tn-cat-check").forEach((chk) => {
    chk.addEventListener("change", () => {
      tnActiveFilters.categories = [...document.querySelectorAll(".tn-cat-check:checked")].map((c) => c.value);
      tnApplyFilters();
    });
  });
}

function tnApplyFilters() {
  let items = [...TN_PRODUCTS];

  if (tnActiveFilters.query.trim() !== "") {
    const q = tnActiveFilters.query.trim().toLowerCase();
    items = items.filter(
      (p) => p.name.toLowerCase().includes(q) || p.brand.toLowerCase().includes(q) || tnCategoryName(p.category).toLowerCase().includes(q)
    );
  }

  if (tnActiveFilters.categories.length > 0) {
    items = items.filter((p) => tnActiveFilters.categories.includes(p.category));
  }

  items = items.filter((p) => tnFinalPrice(p) <= tnActiveFilters.maxPrice);

  switch (tnActiveFilters.sort) {
    case "price-low":
      items.sort((a, b) => tnFinalPrice(a) - tnFinalPrice(b));
      break;
    case "price-high":
      items.sort((a, b) => tnFinalPrice(b) - tnFinalPrice(a));
      break;
    case "rating":
      items.sort((a, b) => b.rating - a.rating);
      break;
    case "discount":
      items.sort((a, b) => b.discount - a.discount);
      break;
    default:
      items.sort((a, b) => a.id - b.id);
  }

  tnFilteredItems = items;
  tnActiveFilters.page = 1;
  tnRenderPage();
}

function tnRenderPage() {
  const items = tnFilteredItems;
  const grid = document.getElementById("tnProductsGrid");
  const countEl = document.getElementById("tnResultsCount");
  const emptyEl = document.getElementById("tnEmptyState");
  const paginationEl = document.getElementById("tnPagination");

  if (countEl) countEl.textContent = items.length;

  const totalPages = Math.max(1, Math.ceil(items.length / TN_PAGE_SIZE));
  if (tnActiveFilters.page > totalPages) tnActiveFilters.page = totalPages;
  const start = (tnActiveFilters.page - 1) * TN_PAGE_SIZE;
  const pageItems = items.slice(start, start + TN_PAGE_SIZE);

  if (grid) {
    if (items.length === 0) {
      grid.innerHTML = "";
      if (emptyEl) emptyEl.classList.remove("d-none");
    } else {
      if (emptyEl) emptyEl.classList.add("d-none");
      grid.innerHTML = pageItems.map(tnProductCardHtml).join("");
    }
  }

  if (paginationEl) {
    if (totalPages <= 1) {
      paginationEl.innerHTML = "";
    } else {
      const cur = tnActiveFilters.page;
      let pagesHtml = "";
      for (let i = 1; i <= totalPages; i++) {
        pagesHtml += `<li class="page-item ${i === cur ? "active" : ""}"><button type="button" class="page-link" onclick="tnGoToPage(${i})">${i}</button></li>`;
      }
      paginationEl.innerHTML = `
        <nav aria-label="Product pages">
          <ul class="pagination tn-pagination justify-content-center mb-0">
            <li class="page-item ${cur === 1 ? "disabled" : ""}"><button type="button" class="page-link" onclick="tnGoToPage(${cur - 1})" aria-label="Previous"><i class="bi bi-chevron-left"></i></button></li>
            ${pagesHtml}
            <li class="page-item ${cur === totalPages ? "disabled" : ""}"><button type="button" class="page-link" onclick="tnGoToPage(${cur + 1})" aria-label="Next"><i class="bi bi-chevron-right"></i></button></li>
          </ul>
        </nav>`;
    }
  }
}

function tnGoToPage(n) {
  const totalPages = Math.max(1, Math.ceil(tnFilteredItems.length / TN_PAGE_SIZE));
  if (n < 1 || n > totalPages) return;
  tnActiveFilters.page = n;
  tnRenderPage();
  const grid = document.getElementById("tnProductsGrid");
  if (grid) grid.scrollIntoView({ behavior: "smooth", block: "start" });
}

document.addEventListener("DOMContentLoaded", () => {
  const grid = document.getElementById("tnProductsGrid");
  if (!grid) return;

  tnRenderCategoryFilters();

  const urlCategory = tnGetUrlParam("category");
  const urlQuery = tnGetUrlParam("q");

  if (urlCategory) {
    const chk = document.getElementById(`cat-${urlCategory}`);
    if (chk) {
      chk.checked = true;
      tnActiveFilters.categories = [urlCategory];
    }
  }
  if (urlQuery) {
    tnActiveFilters.query = urlQuery;
    const searchInputs = document.querySelectorAll(".tn-search-input");
    searchInputs.forEach((i) => (i.value = urlQuery));
  }

  const sortSelect = document.getElementById("tnSortSelect");
  if (sortSelect) {
    sortSelect.addEventListener("change", () => {
      tnActiveFilters.sort = sortSelect.value;
      tnApplyFilters();
    });
  }

  const priceRange = document.getElementById("tnPriceRange");
  const priceLabel = document.getElementById("tnPriceRangeLabel");
  if (priceRange) {
    tnActiveFilters.maxPrice = Number(priceRange.value);
    priceRange.addEventListener("input", () => {
      tnActiveFilters.maxPrice = Number(priceRange.value);
      if (priceLabel) priceLabel.textContent = tnFormatPrice(priceRange.value);
      tnApplyFilters();
    });
  }

  const clearBtn = document.getElementById("tnClearFilters");
  if (clearBtn) {
    clearBtn.addEventListener("click", () => {
      tnActiveFilters = { query: "", categories: [], maxPrice: 200000, sort: "default" };
      document.querySelectorAll(".tn-cat-check").forEach((c) => (c.checked = false));
      if (priceRange) priceRange.value = 200000;
      if (priceLabel) priceLabel.textContent = tnFormatPrice(200000);
      if (sortSelect) sortSelect.value = "default";
      document.querySelectorAll(".tn-search-input").forEach((i) => (i.value = ""));
      tnApplyFilters();
    });
  }

  tnApplyFilters();
});

/* ---------- Global navbar search (redirects to products.html) ---------- */
document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll(".tn-navbar-search-form").forEach((form) => {
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      const input = form.querySelector(".tn-search-input");
      const q = input ? input.value.trim() : "";
      window.location.href = "products.html" + (q ? `?q=${encodeURIComponent(q)}` : "");
    });
  });
});
