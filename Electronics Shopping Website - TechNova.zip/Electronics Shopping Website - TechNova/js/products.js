/* ============================================================
   TechNova — Static Dummy Data
   Products, Categories, Orders, Customers, Reviews
   ============================================================ */

const TN_CATEGORIES = [
  { id: "smartphones", name: "Smartphones", icon: "bi-phone", count: 3 },
  { id: "laptops", name: "Laptops", icon: "bi-laptop", count: 3 },
  { id: "tablets", name: "Tablets", icon: "bi-tablet", count: 2 },
  { id: "headphones", name: "Headphones", icon: "bi-headphones", count: 2 },
  { id: "smartwatches", name: "Smartwatches", icon: "bi-smartwatch", count: 2 },
  { id: "cameras", name: "Cameras", icon: "bi-camera", count: 2 },
  { id: "tvs", name: "TVs", icon: "bi-tv", count: 2 },
  { id: "gaming", name: "Gaming", icon: "bi-controller", count: 2 },
  { id: "accessories", name: "Accessories", icon: "bi-usb-plug", count: 2 },
  { id: "appliances", name: "Home Appliances", icon: "bi-house-gear", count: 2 },
];

const TN_PRODUCTS = [
  { id: 1, name: "Nova X12 Pro", brand: "Nova", category: "smartphones", price: 79999, discount: 12, rating: 4.6, stock: 24, warranty: "1 Year", img: "image/products/nova-x12-pro.svg", desc: "Flagship smartphone with a 120Hz AMOLED display, triple-lens camera system and all-day battery life. Built for speed, tuned for photography." },
  { id: 2, name: "Solace S8", brand: "Solace", category: "smartphones", price: 49999, discount: 8, rating: 4.3, stock: 40, warranty: "1 Year", img: "image/products/solace-s8.svg", desc: "A balanced mid-range phone with a clean display, dependable battery and a camera that handles daylight and low light with equal ease." },
  { id: 3, name: "Orbit Mini", brand: "Orbit", category: "smartphones", price: 29999, discount: 5, rating: 4.1, stock: 55, warranty: "1 Year", img: "image/products/orbit-mini.svg", desc: "Compact and light, the Orbit Mini fits in one hand without giving up a sharp screen or a fast processor." },
  { id: 4, name: "Vertex Book 14", brand: "Vertex", category: "laptops", price: 124999, discount: 10, rating: 4.7, stock: 18, warranty: "2 Years", img: "image/products/vertex-book-14.svg", desc: "A 14-inch ultrabook milled from a single block of aluminium, built for people who carry their whole workday in a bag." },
  { id: 5, name: "ForgeBook Air", brand: "Forge", category: "laptops", price: 89999, discount: 15, rating: 4.4, stock: 22, warranty: "1 Year", img: "image/products/forgebook-air.svg", desc: "Light enough to forget it's in your bag, fast enough to forget it's not a desktop. All-day battery included." },
  { id: 6, name: "Titan Gaming 16", brand: "Titan", category: "laptops", price: 189999, discount: 6, rating: 4.8, stock: 9, warranty: "2 Years", img: "image/products/titan-gaming-16.svg", desc: "A 16-inch gaming powerhouse with a high refresh display and a cooling system built to sustain long sessions." },
  { id: 7, name: "TabOne 11", brand: "TechNova", category: "tablets", price: 39999, discount: 10, rating: 4.5, stock: 30, warranty: "1 Year", img: "image/products/tabone-11.svg", desc: "An 11-inch tablet with a paper-like display mode, stylus support and enough battery for a full flight." },
  { id: 8, name: "PadLite 8", brand: "Orbit", category: "tablets", price: 18999, discount: 5, rating: 4.0, stock: 45, warranty: "1 Year", img: "image/products/padlite-8.svg", desc: "A pocketable 8-inch tablet built for reading, streaming and note-taking on the move." },
  { id: 9, name: "EchoBeat Pro", brand: "Echo", category: "headphones", price: 14999, discount: 20, rating: 4.6, stock: 60, warranty: "1 Year", img: "image/products/echobeat-pro.svg", desc: "Over-ear headphones with adaptive noise cancellation and 40 hours of battery on a single charge." },
  { id: 10, name: "PulseBuds Air", brand: "Pulse", category: "headphones", price: 6999, discount: 15, rating: 4.2, stock: 80, warranty: "6 Months", img: "image/products/pulsebuds-air.svg", desc: "True wireless earbuds with a snug fit, punchy bass and a charging case that fits any pocket." },
  { id: 11, name: "ChronoFit Pro", brand: "Chrono", category: "smartwatches", price: 17999, discount: 10, rating: 4.4, stock: 35, warranty: "1 Year", img: "image/products/chronofit-pro.svg", desc: "A fitness-first smartwatch that tracks heart rate, sleep and workouts, and lasts a full week per charge." },
  { id: 12, name: "PulseWatch SE", brand: "Pulse", category: "smartwatches", price: 9999, discount: 8, rating: 4.1, stock: 50, warranty: "1 Year", img: "image/products/pulsewatch-se.svg", desc: "An everyday smartwatch with call handling, notifications and a battery that keeps up with your week." },
  { id: 13, name: "LensPro X100", brand: "LensPro", category: "cameras", price: 84999, discount: 7, rating: 4.7, stock: 12, warranty: "2 Years", img: "image/products/lenspro-x100.svg", desc: "A mirrorless camera built for people who shoot both stills and video, with in-body stabilisation as standard." },
  { id: 14, name: "ActionCam 4K", brand: "Nova", category: "cameras", price: 24999, discount: 12, rating: 4.3, stock: 28, warranty: "1 Year", img: "image/products/actioncam-4k.svg", desc: "A rugged 4K action camera rated for water, dust and drops, with stabilisation tuned for movement." },
  { id: 15, name: "VividView 55", brand: "Vivid", category: "tvs", price: 54999, discount: 18, rating: 4.5, stock: 15, warranty: "2 Years", img: "image/products/vividview-55.svg", desc: "A 55-inch 4K smart TV with rich contrast and a remote that actually finds what you want to watch." },
  { id: 16, name: "VividView 43", brand: "Vivid", category: "tvs", price: 32999, discount: 14, rating: 4.2, stock: 20, warranty: "2 Years", img: "image/products/vividview-43.svg", desc: "A compact 43-inch smart TV that fits smaller rooms without giving up on picture quality." },
  { id: 17, name: "Titan Controller X", brand: "Titan", category: "gaming", price: 5999, discount: 10, rating: 4.4, stock: 70, warranty: "1 Year", img: "image/products/titan-controller-x.svg", desc: "A precision gaming controller with programmable triggers and a grip built for long sessions." },
  { id: 18, name: "GlideMouse RGB", brand: "Forge", category: "gaming", price: 3499, discount: 5, rating: 4.3, stock: 90, warranty: "1 Year", img: "image/products/glidemouse-rgb.svg", desc: "A lightweight gaming mouse with a honeycomb shell and a sensor tuned for fast flicks." },
  { id: 19, name: "PowerHub 65W", brand: "TechNova", category: "accessories", price: 2499, discount: 0, rating: 4.5, stock: 120, warranty: "1 Year", img: "image/products/powerhub-65w.svg", desc: "A compact 65W charger with three ports, fast enough for a laptop and two phones at once." },
  { id: 20, name: "ClearCase Armor", brand: "TechNova", category: "accessories", price: 999, discount: 0, rating: 4.0, stock: 200, warranty: "6 Months", img: "image/products/clearcase-armor.svg", desc: "A drop-tested clear case that shows off your phone's colour without showing off scratches." },
];

const TN_ORDERS = [
  { id: "TN-1001", customer: "Ravi Mehta", product: "Nova X12 Pro", qty: 1, amount: 70399, status: "Delivered" },
  { id: "TN-1002", customer: "Anita Shah", product: "EchoBeat Pro", qty: 2, amount: 23998, status: "Shipped" },
  { id: "TN-1003", customer: "Karan Patel", product: "Vertex Book 14", qty: 1, amount: 112499, status: "Processing" },
  { id: "TN-1004", customer: "Priya Nair", product: "ChronoFit Pro", qty: 1, amount: 16199, status: "Delivered" },
  { id: "TN-1005", customer: "Sameer Joshi", product: "VividView 55", qty: 1, amount: 45099, status: "Cancelled" },
];

const TN_CUSTOMERS = [
  { name: "Ravi Mehta", email: "ravi.mehta@example.com", phone: "+91 98765 43210", city: "Ahmedabad", status: "Active" },
  { name: "Anita Shah", email: "anita.shah@example.com", phone: "+91 91234 56780", city: "Rajkot", status: "Active" },
  { name: "Karan Patel", email: "karan.patel@example.com", phone: "+91 99887 66554", city: "Surat", status: "Active" },
  { name: "Priya Nair", email: "priya.nair@example.com", phone: "+91 90909 80808", city: "Vadodara", status: "Inactive" },
  { name: "Sameer Joshi", email: "sameer.joshi@example.com", phone: "+91 93333 22110", city: "Mumbai", status: "Active" },
];

const TN_REVIEWS = [
  { name: "Ravi Mehta", city: "Ahmedabad", rating: 5, text: "Ordered a phone on Monday, it was on my desk by Wednesday. Packaging was solid and the site made comparing models painless." },
  { name: "Anita Shah", city: "Rajkot", rating: 4, text: "Good range of headphones at every price point. Wish the filters remembered my last search, but I found what I needed fast." },
  { name: "Karan Patel", city: "Surat", rating: 5, text: "Bought a laptop for work — the product page had exactly the specs I needed to decide without calling support." },
];

/* Helpers */
function tnFormatPrice(n) {
  return "₹" + Math.round(n).toLocaleString("en-IN");
}
function tnFinalPrice(p) {
  return p.price - (p.price * p.discount) / 100;
}
function tnGetProduct(id) {
  return TN_PRODUCTS.find((p) => p.id === Number(id));
}
function tnCategoryName(id) {
  const c = TN_CATEGORIES.find((c) => c.id === id);
  return c ? c.name : id;
}
