/* ============================================================
   TechNova Admin — Sidebar Toggle
   ============================================================ */

document.addEventListener("DOMContentLoaded", () => {
  const toggle = document.getElementById("tnSidebarToggle");
  const sidebar = document.getElementById("tnAdminSidebar");
  if (toggle && sidebar) {
    toggle.addEventListener("click", () => sidebar.classList.toggle("tn-open"));
    document.addEventListener("click", (e) => {
      if (!sidebar.contains(e.target) && !toggle.contains(e.target)) {
        sidebar.classList.remove("tn-open");
      }
    });
  }
});
