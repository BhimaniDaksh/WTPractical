/* ============================================================
   TechNova — Global Script
   Toast, Back to Top, Smooth Scroll, Card Renderers
   ============================================================ */

/* ---------- Toast ---------- */
let tnToastTimer = null;
function tnShowToast(msg) {
  let toast = document.getElementById("tnToast");
  if (!toast) {
    toast = document.createElement("div");
    toast.id = "tnToast";
    toast.className = "tn-toast";
    toast.innerHTML = `<i class="bi bi-check-circle-fill"></i><span id="tnToastMsg"></span>`;
    document.body.appendChild(toast);
  }
  document.getElementById("tnToastMsg").textContent = msg;
  toast.classList.add("show");
  clearTimeout(tnToastTimer);
  tnToastTimer = setTimeout(() => toast.classList.remove("show"), 2400);
}

/* ---------- Back to top ---------- */
document.addEventListener("DOMContentLoaded", () => {
  const btn = document.createElement("button");
  btn.className = "tn-back-top";
  btn.setAttribute("aria-label", "Back to top");
  btn.innerHTML = `<i class="bi bi-arrow-up"></i>`;
  document.body.appendChild(btn);

  window.addEventListener("scroll", () => {
    btn.classList.toggle("show", window.scrollY > 400);
  });
  btn.addEventListener("click", () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  });

  /* Smooth scroll for on-page anchors */
  document.querySelectorAll('a[href^="#"]:not([href="#"])').forEach((a) => {
    a.addEventListener("click", (e) => {
      const target = document.querySelector(a.getAttribute("href"));
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: "smooth", block: "start" });
      }
    });
  });

  /* Active nav link highlighting */
  const page = window.location.pathname.split("/").pop() || "index.html";
  document.querySelectorAll(".tn-navbar .nav-link").forEach((link) => {
    const href = link.getAttribute("href");
    if (href === page) link.classList.add("active");
  });

  tnRenderFeaturedSections();
});

/* ---------- Star rating markup ---------- */
function tnStarsHtml(rating) {
  let html = "";
  for (let i = 1; i <= 5; i++) {
    if (rating >= i) html += '<i class="bi bi-star-fill"></i>';
    else if (rating >= i - 0.5) html += '<i class="bi bi-star-half"></i>';
    else html += '<i class="bi bi-star"></i>';
  }
  return html;
}

/* ---------- Product card markup ---------- */
function tnProductCardHtml(p) {
  const finalPrice = tnFinalPrice(p);
  return `
    <div class="col-6 col-md-4 col-lg-3">
      <div class="tn-product-card">
        <a href="product-details.html?id=${p.id}" class="tn-product-thumb d-block">
          ${p.discount > 0 ? `<span class="tn-badge-sale">-${p.discount}%</span>` : ""}
          <span class="tn-badge-stock">${p.stock > 0 ? p.stock + " in stock" : "Out of stock"}</span>
          <img src="${p.img}" alt="${p.name}" loading="lazy">
        </a>
        <button type="button" class="tn-wish-btn" aria-label="Save to wishlist"><i class="bi bi-heart"></i></button>
        <div class="tn-product-body">
          <div class="tn-product-brand">${p.brand}</div>
          <a href="product-details.html?id=${p.id}" class="tn-product-name">${p.name}</a>
          <div class="tn-product-rating">${tnStarsHtml(p.rating)} <span class="count">(${p.rating})</span></div>
          <div class="tn-product-price-row">
            <span class="tn-price-now">${tnFormatPrice(finalPrice)}</span>
            ${p.discount > 0 ? `<span class="tn-price-old">${tnFormatPrice(p.price)}</span>` : ""}
          </div>
          <button type="button" class="btn btn-tn-primary btn-sm tn-add-cart-btn" onclick="tnAddToCart(${p.id})" ${p.stock === 0 ? "disabled" : ""}>
            <i class="bi bi-bag-plus"></i> Add to Cart
          </button>
        </div>
      </div>
    </div>`;
}

/* ---------- Home page sections (featured / latest / best sellers) ---------- */
function tnRenderFeaturedSections() {
  const featured = document.getElementById("tnFeaturedGrid");
  if (featured) {
    const items = [...TN_PRODUCTS].sort((a, b) => b.discount - a.discount).slice(0, 8);
    featured.innerHTML = items.map(tnProductCardHtml).join("");
  }
  const latest = document.getElementById("tnLatestGrid");
  if (latest) {
    const items = [...TN_PRODUCTS].slice(-8).reverse();
    latest.innerHTML = items.map(tnProductCardHtml).join("");
  }
  const bestSellers = document.getElementById("tnBestSellerGrid");
  if (bestSellers) {
    const items = [...TN_PRODUCTS].sort((a, b) => b.rating - a.rating).slice(0, 4);
    bestSellers.innerHTML = items.map(tnProductCardHtml).join("");
  }
  const catGrid = document.getElementById("tnCategoryGrid");
  if (catGrid) {
    catGrid.innerHTML = TN_CATEGORIES.map(
      (c) => `
      <div class="col-6 col-md-3 col-lg-2">
        <a href="products.html?category=${c.id}" class="tn-cat-card d-block text-decoration-none">
          <div class="tn-cat-icon"><i class="bi ${c.icon}"></i></div>
          <div class="tn-cat-name">${c.name}</div>
          <div class="tn-cat-count">${c.count} items</div>
        </a>
      </div>`
    ).join("");
  }
  const reviewGrid = document.getElementById("tnReviewGrid");
  if (reviewGrid) {
    reviewGrid.innerHTML = TN_REVIEWS.map(
      (r) => `
      <div class="col-md-4">
        <div class="tn-review-card">
          <div class="tn-review-stars">${tnStarsHtml(r.rating)}</div>
          <p class="mb-3">"${r.text}"</p>
          <div class="d-flex align-items-center gap-2">
            <div class="tn-review-avatar">${r.name.charAt(0)}</div>
            <div>
              <div class="fw-semibold" style="color:var(--tn-heading);font-size:0.9rem;">${r.name}</div>
              <div class="text-muted" style="font-size:0.8rem;">${r.city}</div>
            </div>
          </div>
        </div>
      </div>`
    ).join("");
  }
}

// ---------- Navbar scroll shadow ----------
(function () {
  const nav = document.querySelector(".tn-navbar");
  if (!nav) return;
  const toggle = () => {
    if (window.scrollY > 12) nav.classList.add("tn-navbar-scrolled");
    else nav.classList.remove("tn-navbar-scrolled");
  };
  window.addEventListener("scroll", toggle, { passive: true });
  toggle();
})();
