/* ============================================================
   TechNova — Cart Logic (localStorage based)
   ============================================================ */

const TN_CART_KEY = "tn_cart";

function tnGetCart() {
  try {
    return JSON.parse(localStorage.getItem(TN_CART_KEY)) || [];
  } catch (e) {
    return [];
  }
}

function tnSaveCart(cart) {
  localStorage.setItem(TN_CART_KEY, JSON.stringify(cart));
  tnUpdateCartBadge();
}

function tnAddToCart(productId, qty = 1) {
  const cart = tnGetCart();
  const existing = cart.find((i) => i.id === Number(productId));
  if (existing) {
    existing.qty += qty;
  } else {
    cart.push({ id: Number(productId), qty });
  }
  tnSaveCart(cart);
  tnShowToast("Added to cart");
}

function tnRemoveFromCart(productId) {
  let cart = tnGetCart();
  cart = cart.filter((i) => i.id !== Number(productId));
  tnSaveCart(cart);
  if (typeof tnRenderCartPage === "function") tnRenderCartPage();
  tnShowToast("Removed from cart");
}

function tnChangeQty(productId, delta) {
  const cart = tnGetCart();
  const item = cart.find((i) => i.id === Number(productId));
  if (!item) return;
  item.qty += delta;
  if (item.qty < 1) item.qty = 1;
  tnSaveCart(cart);
  if (typeof tnRenderCartPage === "function") tnRenderCartPage();
}

function tnCartCount() {
  return tnGetCart().reduce((sum, i) => sum + i.qty, 0);
}

function tnUpdateCartBadge() {
  document.querySelectorAll(".tn-cart-badge").forEach((el) => {
    el.textContent = tnCartCount();
  });
}

/* ---------- Cart Page Rendering ---------- */
function tnRenderCartPage() {
  const wrap = document.getElementById("tnCartItems");
  if (!wrap) return;
  const cart = tnGetCart();

  if (cart.length === 0) {
    wrap.innerHTML = `
      <div class="text-center py-5">
        <i class="bi bi-cart-x" style="font-size:3rem;color:var(--tn-border);"></i>
        <h5 class="mt-3">Your cart is empty</h5>
        <p class="text-muted">Browse our products and add something you like.</p>
        <a href="products.html" class="btn btn-tn-primary">Shop Products</a>
      </div>`;
    tnUpdateSummary(0, 0);
    return;
  }

  let html = "";
  let subtotal = 0;
  let totalDiscount = 0;

  cart.forEach((item) => {
    const p = tnGetProduct(item.id);
    if (!p) return;
    const lineFinal = tnFinalPrice(p) * item.qty;
    const lineOriginal = p.price * item.qty;
    subtotal += lineOriginal;
    totalDiscount += lineOriginal - lineFinal;

    html += `
      <div class="tn-cart-item">
        <div class="row align-items-center g-3">
          <div class="col-auto">
            <img src="${p.img}" alt="${p.name}">
          </div>
          <div class="col-12 col-md">
            <div class="tn-product-brand">${p.brand}</div>
            <div class="tn-product-name mb-1">${p.name}</div>
            <div class="tn-price-now">${tnFormatPrice(tnFinalPrice(p))}</div>
          </div>
          <div class="col-12 col-md-auto">
            <div class="tn-qty-box">
              <button type="button" onclick="tnChangeQty(${p.id}, -1)" aria-label="Decrease quantity">−</button>
              <span class="tn-qty-val">${item.qty}</span>
              <button type="button" onclick="tnChangeQty(${p.id}, 1)" aria-label="Increase quantity">+</button>
            </div>
          </div>
          <div class="col-12 col-md-auto text-md-end">
            <div class="fw-bold" style="font-family:var(--tn-font-display);color:var(--tn-heading);">${tnFormatPrice(lineFinal)}</div>
          </div>
          <div class="col-12 col-md-auto text-md-end">
            <button type="button" class="btn btn-sm btn-tn-outline" onclick="tnRemoveFromCart(${p.id})">
              <i class="bi bi-trash3"></i> Remove
            </button>
          </div>
        </div>
      </div>`;
  });

  wrap.innerHTML = html;
  tnUpdateSummary(subtotal, totalDiscount);
}

function tnUpdateSummary(subtotal, discount) {
  const elSub = document.getElementById("tnSubtotal");
  const elDisc = document.getElementById("tnDiscount");
  const elGrand = document.getElementById("tnGrandTotal");
  const shipping = subtotal > 0 ? (subtotal >= 50000 ? 0 : 199) : 0;
  const elShip = document.getElementById("tnShipping");
  if (elSub) elSub.textContent = tnFormatPrice(subtotal);
  if (elDisc) elDisc.textContent = "− " + tnFormatPrice(discount);
  if (elShip) elShip.textContent = shipping === 0 ? "Free" : tnFormatPrice(shipping);
  if (elGrand) elGrand.textContent = tnFormatPrice(subtotal - discount + shipping);

  const checkoutBtn = document.getElementById("tnCheckoutBtn");
  if (checkoutBtn) checkoutBtn.disabled = subtotal === 0;
}

document.addEventListener("DOMContentLoaded", () => {
  tnUpdateCartBadge();
  tnRenderCartPage();

  const checkoutBtn = document.getElementById("tnCheckoutBtn");
  if (checkoutBtn) {
    checkoutBtn.addEventListener("click", () => {
      tnShowToast("Order placed successfully!");
      localStorage.removeItem(TN_CART_KEY);
      setTimeout(() => tnRenderCartPage(), 400);
      tnUpdateCartBadge();
    });
  }
});
